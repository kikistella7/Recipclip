#!/usr/bin/env python3
"""Generate app icons for PWA"""
import struct, zlib, base64

def make_png(size, bg_color, emoji_placeholder=True):
    """Create a simple PNG with background color"""
    # We'll create a simple colored square PNG
    width = height = size
    
    # Create image data (RGBA)
    r, g, b = bg_color
    row = bytes([0] + [r, g, b, 255] * width)  # filter byte + RGBA pixels
    raw = row * height
    
    compressed = zlib.compress(raw, 9)
    
    def chunk(name, data):
        c = name + data
        return struct.pack('>I', len(data)) + c + struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
    png += chunk(b'IDAT', compressed)
    png += chunk(b'IEND', b'')
    return png

# Generate 192x192 icon
icon192 = make_png(192, (44, 36, 23))
with open('/home/claude/recipe-app/public/icon-192.png', 'wb') as f:
    f.write(icon192)

# Generate 512x512 icon
icon512 = make_png(512, (44, 36, 23))
with open('/home/claude/recipe-app/public/icon-512.png', 'wb') as f:
    f.write(icon512)

print("Icons generated!")
